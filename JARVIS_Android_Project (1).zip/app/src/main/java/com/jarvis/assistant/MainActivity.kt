package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onTranscript: ((String) -> Unit)? = null
    private var onStatus: ((String) -> Unit)? = null

    private val audioPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) listenNow() else onStatus?.invoke("Microphone permission is required.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            var heard by remember { mutableStateOf("Awaiting your command, sir.") }
            var reply by remember { mutableStateOf("Good day. JARVIS is online.") }
            var status by remember { mutableStateOf("SYSTEM READY") }
            onTranscript = { heard = it; reply = respond(it); speak(reply); status = "READY" }
            onStatus = { status = it }
            JarvisScreen(
                heard = heard, reply = reply, status = status,
                onMic = {
                    onStatus?.invoke("LISTENING…")
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) listenNow()
                    else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onSpeak = { speak(reply) }
            )
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts?.language = Locale.UK
            tts?.setSpeechRate(0.88f)
            tts?.setPitch(0.82f)
        }
    }

    private fun listenNow() {
        val recognizer = speechRecognizer ?: run {
            onStatus?.invoke("Speech recognition is unavailable on this device.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onStatus?.invoke("LISTENING…") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onStatus?.invoke("PROCESSING…") }
            override fun onError(error: Int) { onStatus?.invoke("VOICE INPUT ERROR — TAP TO TRY AGAIN") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) onStatus?.invoke("I didn't catch that. Please try again.")
                else onTranscript?.invoke(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun respond(input: String): String {
        val q = input.lowercase(Locale.UK)
        return when {
            "hello" in q || "hi" in q -> "Good day. How may I assist you?"
            "your name" in q || "who are you" in q -> "I am JARVIS, your personal Android assistant."
            "time" in q -> "The current time is " + java.text.SimpleDateFormat("h:mm a", Locale.UK).format(java.util.Date())
            "date" in q -> "Today is " + java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.UK).format(java.util.Date())
            "open settings" in q -> "I can help with that in a future Android-control update. For now, please open Settings manually."
            else -> "I heard: $input. My conversational AI connection has not been configured yet."
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(
    heard: String, reply: String, status: String,
    onMic: () -> Unit, onSpeak: () -> Unit
) {
    val cyan = Color(0xFF55DFFF)
    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = Color(0xFF050B16))) {
        Column(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF101F36), Color(0xFF030711))))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(24.dp))
                Text("J.A.R.V.I.S.", color = cyan, fontSize = 30.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp)
                Text("PERSONAL AI SYSTEM", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(42.dp))
                Box(
                    modifier = Modifier.size(218.dp).background(
                        Brush.radialGradient(listOf(Color(0x5534D9FF), Color(0x1122AADD), Color.Transparent)),
                        CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(shape = CircleShape, color = Color(0x3322CFFF), border = androidx.compose.foundation.BorderStroke(1.dp, cyan.copy(alpha = .7f))) {
                        Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                            Text("J", color = cyan, fontSize = 76.sp, fontWeight = FontWeight.Thin)
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text(status, color = cyan, fontSize = 12.sp, letterSpacing = 2.sp)
            }
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("YOU SAID", color = cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                Text(heard, color = Color.White, fontSize = 17.sp)
                Divider(color = cyan.copy(alpha = .25f))
                Text("JARVIS", color = cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                Text(reply, color = Color.White, fontSize = 17.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                FilledIconButton(
                    onClick = onMic,
                    modifier = Modifier.size(76.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = cyan, contentColor = Color(0xFF04101D))
                ) { Icon(Icons.Default.Mic, contentDescription = "Speak to JARVIS", modifier = Modifier.size(34.dp)) }
                Spacer(Modifier.height(10.dp))
                Text("TAP TO SPEAK", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 2.sp)
                TextButton(onClick = onSpeak) { Text("REPEAT RESPONSE", color = cyan) }
            }
        }
    }
}
