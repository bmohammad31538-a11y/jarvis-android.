# JARVIS — Android starter project

A brand-new Kotlin Android project (not based on MAX) with a futuristic interface, tap-to-talk speech input, and British-English text-to-speech.

## Current features
- Android microphone permission flow
- Speech recognition using the device's Android speech service (`en-GB`)
- Spoken responses using Android Text-to-Speech (`Locale.UK`)
- Simple local demo commands (greetings, name, date, time)
- Dark blue JARVIS-inspired interface

## Important limitations in this starter
This is a **starter build**, not yet the complete production assistant. It does not yet include:
- Always-on wake-word detection ("Jarvis", "Hey Jarvis", "Hello Jarvis")
- A connected conversational AI backend
- A production-grade background microphone foreground service
- Advanced phone control or smart-home integrations

Those need separate implementation, Android-version testing, and explicit permissions. Android may restrict background microphone access; a wake-word feature must use a compliant foreground service and a dedicated on-device detection engine. Do not expect the wake word to work in this starter.

## Build an APK using only your Samsung phone
1. Create a GitHub account or sign in using Chrome.
2. Create a new repository named `jarvis-android`.
3. Upload the contents of this ZIP to the repository (the files must be at the repository root; do not upload the enclosing folder).
4. Open the **Actions** tab and allow GitHub Actions if prompted.
5. The workflow builds a debug APK. Open the completed workflow run and download the `JARVIS-debug-apk` artifact.
6. Extract the downloaded artifact and install the APK. Android may ask you to allow installs from Chrome or Files.

## Security
Never put an AI provider secret/API key in this Android app or a public GitHub repository. A secure AI connection should go through a private backend that stores the secret server-side.

## Project details
- Application ID: `com.jarvis.assistant`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Voice language: British English (`en-GB` / `Locale.UK`)
